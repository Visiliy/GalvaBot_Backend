from flask import Flask, Response, render_template
import cv2
import mediapipe as mp
import json
import os

app = Flask(__name__)

# Инициализация MediaPipe Face Mesh
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(min_detection_confidence=0.5)


def generate_frames(res):
    # Загрузка данных из файла
    with open(f"library/{res}.txt", "r", encoding="utf-8") as f:
        pocket = json.loads(f.read())

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise IOError("Ошибка видео")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            # Обработка кадра
            results = face_mesh.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

            if results.multi_face_landmarks:
                for face_land in results.multi_face_landmarks:
                    idx = 0
                    for elem in face_land.landmark:
                        if idx in pocket:
                            x = int(elem.x * frame.shape[1])
                            y = int(elem.y * frame.shape[0])
                            cv2.circle(frame, (x, y), 3, (0, 255, 0), -1)
                        idx += 1

            # Зеркальное отражение и добавление текста
            frame = cv2.flip(frame, 1)

            # Кодирование кадра в JPEG
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    finally:
        cap.release()


@app.route('/')
def index():
    # Получаем список доступных файлов в папке library
    files = [f.split('.')[0] for f in os.listdir('library') if f.endswith('.txt')]
    return render_template('index.html', files=files)


@app.route('/video_feed/<res>')
def video_feed(res):
    return Response(generate_frames(res),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)