from flask import *
import os

app = Flask(__name__)


@app.route("/image_markup", methods=['POST'])
def image_markup():
    try:
        image = request.files['image']
        path = "img/image.jpg"
        image.save(path)
        number_parts_per_class = [5, 4, 7, 8]
        answer = {
            "class_count": len(number_parts_per_class),
            "number_of_details": sum(number_parts_per_class)
        }
        for index, count in enumerate(number_parts_per_class):
            answer[f"class{index}"] = count
        os.remove(path)
        return jsonify(answer, 200)
    except Exception as e:
        print(e)
        return jsonify(["Server error"], 502)


@app.route("/statistique", methods=['GET'])
def statistique():
    classified = 13
    unclassified = 11
    data = {
        "classified": classified,
        "unclassified": unclassified
    }
    return jsonify(data, 200)


def main():
    app.run(host='0.0.0.0', port=5000)


if __name__ == "__main__":
    main()
