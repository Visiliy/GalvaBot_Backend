import requests


url = 'http://localhost:8090/statistique'

response = requests.get(url)
print(response.status_code)
print(response.text)