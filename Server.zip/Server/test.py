import requests

# Скачиваем изображение по ссылке
image_url = 'https://proproprogs.ru/htm/flask/files/dobavlenie-i-otobrazhenie-statey-iz-bd.files/image003.jpg'
image_response = requests.get(image_url)
image_response.raise_for_status()  # Проверка на ошибки

# Готовим файл для отправки
files = {
    'image': ('image003.jpg', image_response.content, 'image/jpeg')
}

# Адрес вашего Flask-сервера
upload_url = 'http://localhost:8090/image_markup'

# Отправляем POST-запрос
response = requests.post(upload_url, files=files)
print(response.status_code)
print(response.text)